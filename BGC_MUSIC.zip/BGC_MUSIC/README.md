### Best Smart Voice Chat Music Robot For Telegram Groups ...


<p align="center"><a href="https://t.me/Shailendra34"><img src="https://te.legra.ph/file/030002064bb3b48809ffa.jpg"></a></p>




# Deploy To Railway


[![Deploy+on+Railway](https://railway.app/button.svg)](https://railway.app/new/template?template=https://github.com/Shailendra34/Hero&envs=API_ID,API_HASH,BOT_TOKEN,STRING_SESSION)


# Deploy To Heroku


[![Deploy+On+Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)



### Get String Session


[![GenerateString](https://img.shields.io/badge/repl.it-generateString-yellowgreen)](https://replit.com/@AdityaHalder/StringSession)



# CREDIT


~ [ADITYA HALDER](https://t.me/adityahalder)