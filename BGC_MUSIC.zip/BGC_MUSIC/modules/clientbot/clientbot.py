from config import API_HASH, API_ID, BOT_TOKEN, STRING_SESSION
from pyrogram import Client
from pytgcalls import PyTgCalls

bot = Client(
    ":groove:",
    API_ID,
    API_HASH,
    bot_token=BOT_TOKEN,
    plugins={"root": "plugins"},
)

user = Client(
    STRING_SESSION,
    api_id=API_ID,
    api_hash=API_HASH,
)

call_py = PyTgCalls(user)
